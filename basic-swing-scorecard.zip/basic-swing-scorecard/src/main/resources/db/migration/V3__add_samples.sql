/*Add some samples*/
INSERT INTO contacts (name, contacts) VALUES ('Dave Smith', 'dave.smith@sky.com');
INSERT INTO contacts (name, contacts) VALUES ('Kay Smith', 'kay.smith@sky.com');
INSERT INTO contacts (name, contacts) VALUES ('Caroline Smith', 'caz.smith@sky.com');