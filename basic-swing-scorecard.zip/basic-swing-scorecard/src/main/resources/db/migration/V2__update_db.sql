/*Add contacts column*/
ALTER TABLE contacts ADD COLUMN contacts varchar(255);