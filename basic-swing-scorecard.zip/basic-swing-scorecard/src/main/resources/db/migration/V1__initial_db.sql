/* Create contents table */
CREATE TABLE contacts (
	id bigint auto_increment NOT NULL,
	name varchar(120) NOT NULL,
	primary key(id)
);