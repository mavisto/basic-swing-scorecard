package uk.co.mavisto.swingscorecard.app;

public class HoleDetailsHelper {

}
